
package c_collection;
import java.util.ArrayList;

class aArrayListEx
{
	public static void main(String[] args) 
	{
		dataSet();
		
		// dataSet() 안의 변수 값들을 여기서 출력한다면??
		
	}

	static void dataSet()
	{
		String	name = "김태희";
		int		age = 31;
		double	height = 162.3;



	}
}
