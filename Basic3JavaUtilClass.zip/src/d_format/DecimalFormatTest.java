package d_format;

import java.text.DecimalFormat;

public class DecimalFormatTest {

	public static void main(String[] args) {
		
		double [] data = { 12345.6789,  2222.22,  99.99999,  1234.5,   987.654 };

		// 세자리 마다 꼼마(,)를 설정하고 소수 3자리까지만 출력하는 형식으로 

		//### 
	}

}
