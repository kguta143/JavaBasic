package d_format;

import java.text.ChoiceFormat;

public class ChoiceFormatTest {

	public static void main(String[] args) {
		
		int []scores = { 88, 33, 55, 99, 44, 77, 100 };
		
		double [ ]limits = { 60, 70, 80, 90 };
		String [] grades = { "D", "C", "B", "A"};
		
		//### 
		
	}

}
