package d_format;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateFormatTest {

	public static void main(String[] args) {
		
		Date today = new Date();
		System.out.println( today );

		// oooo 년 oo 월 oo 일  ooo 요일  oo 시 oo 분  oo 초

		
	} 

}
