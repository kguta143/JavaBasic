package d_format;

import java.text.MessageFormat;

public class MessageFormatTest {

	public static void main(String[] args) {
		
		String message = "친애하는  <{0}> {1}님,  [ 본문 생략. . . ]  아무쪼록 감사드립니다. ";

		String[][] data = { 
				{"홍길동","부장님"},
				{"홍길자","사원님"},
				{"홍길순","과장님"},
				{"홍길숙","대리님"},
				{"홍홍홍","사원님"},
		};
		
		//### 
		
	}

}
