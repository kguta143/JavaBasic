package h_inherit;

public class Umma {
	public void gene() {
		System.out.println("부모는 부모다");
	}
	
	public void job() {
		System.out.println("엄마는 대장");
	}
}
