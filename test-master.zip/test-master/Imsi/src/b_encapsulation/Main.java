package b_encapsulation;

public class Main {

	public static void main(String[] args) {

		
		
	}
	/*
	 * [ 결론내기 ] 캡슐화란??? 
	 */
}
