package d_constructor;

import java.util.Scanner;

public class MainArray {
	
	/**
	 * 	3명의 학생 정보를 입력받아 각 학생별 총점 평균을 구한다면
	 */
	
	public static void main(String[] args) {
	
		
				
		// 추가적으로 각 과목별 총점을 구한다면?
				
	}

}
