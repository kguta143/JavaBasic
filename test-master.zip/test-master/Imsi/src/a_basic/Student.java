package a_basic;

public class Student {

	
	
}
