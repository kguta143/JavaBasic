package g_access.sub;

// 1. 동일한 패키지에서 확인
class Main
{
	public static void main(String[] args) 
	{
		Access me = new Access();
		// 에러나는 부분을 주석으로 처리
		
		
		me.output();
	}
}
