package g_access;

import g_access.sub.Access;

// 2. 다른 패키지에서 확인
class Main
{
	public static void main(String[] args) 
	{
		Access me = new Access();
	
		
		me.output();
	}
}

