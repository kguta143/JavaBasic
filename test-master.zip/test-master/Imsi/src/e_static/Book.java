package e_static;

public class Book {
	int count;

	public Book(){
		count++;
		System.out.println("책 한개 생성");
	}
	
	
}
